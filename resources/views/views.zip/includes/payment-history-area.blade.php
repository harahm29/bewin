<!--Start payment-history area -->
<div class="payment-history-area bg-color-2 fix area-padding">
            <div class="container">
                <div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="section-headline text-center">
							<h3>Lottery Results</h3>
							<p>Dummy text is also used to demonstrate the appearance of different typefaces and layouts</p>
						</div>
					</div>
				</div>
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="deposite-content">
                            <div class="diposite-box">
                                <div class="deposite-table">
                                    <table>
                                        <tr>
                                            <th>Name</th>
                                            <th>Draw Date</th>
                                            <th>Winning Number</th>
                                            <th>Winning price</th>
                                            <th>Lottery name</th>
                                        </tr>
                                        <tr>
                                           <td><img src="{{url('public/frontend/img/icon/m.png')}}" alt="">Ragner Lorth</td>
                                            <td>02-03-2019</td>
                                            <td>
                                               <ul class="self-number">
                                                    <li><a href="#">12</a></li>
                                                    <li><a href="#">23</a></li>
                                                    <li><a href="#">24</a></li>
                                                    <li><a href="#">26</a></li>
                                                    <li><a href="#">31</a></li>
                                                </ul>
                                            </td>
                                            <td>$150k</td>
                                            <td><img src="{{url('public/frontend/img/icon/j.png')}}" alt="">Red Jackpot</td>
                                        </tr>
                                        <tr>
                                           <td><img src="{{url('public/frontend/img/icon/m1.png')}}" alt="">Ragner Lorth</td>
                                            <td>02-03-2019</td>
                                            <td>
                                               <ul class="self-number">
                                                    <li><a href="#">12</a></li>
                                                    <li><a href="#">23</a></li>
                                                    <li><a href="#">24</a></li>
                                                    <li><a href="#">26</a></li>
                                                    <li><a href="#">31</a></li>
                                                </ul>
                                            </td>
                                            <td>$150k</td>
                                            <td><img src="{{url('public/frontend/img/icon/j1.png')}}" alt="">Mega Millions</td>
                                        </tr>
                                        <tr>
                                           <td><img src="{{url('public/frontend/img/icon/m2.png')}}" alt="">Ragner Lorth</td>
                                            <td>02-03-2019</td>
                                            <td>
                                               <ul class="self-number">
                                                    <li><a href="#">12</a></li>
                                                    <li><a href="#">23</a></li>
                                                    <li><a href="#">24</a></li>
                                                    <li><a href="#">26</a></li>
                                                    <li><a href="#">31</a></li>
                                                </ul>
                                            </td>
                                            <td>$150k</td>
                                            <td><img src="{{url('public/frontend/img/icon/j2.png')}}" alt="">Miami Jackpot</td>
                                        </tr>
                                        <tr>
                                           <td><img src="{{url('public/frontend/img/icon/m3.png')}}" alt="">Ragner Lorth</td>
                                            <td>02-03-2019</td>
                                            <td>
                                               <ul class="self-number">
                                                    <li><a href="#">12</a></li>
                                                    <li><a href="#">23</a></li>
                                                    <li><a href="#">24</a></li>
                                                    <li><a href="#">26</a></li>
                                                    <li><a href="#">31</a></li>
                                                </ul>
                                            </td>
                                            <td>$150k</td>
                                            <td><img src="{{url('public/frontend/img/icon/j3.png')}}" alt="">Euro Jackpot</td>
                                        </tr>
                                        <tr>
                                           <td><img src="{{url('public/frontend/img/icon/m4.png')}}" alt="">Ragner Lorth</td>
                                            <td>02-03-2019</td>
                                            <td>
                                               <ul class="self-number">
                                                    <li><a href="#">12</a></li>
                                                    <li><a href="#">23</a></li>
                                                    <li><a href="#">24</a></li>
                                                    <li><a href="#">26</a></li>
                                                    <li><a href="#">31</a></li>
                                                </ul>
                                            </td>
                                            <td>$150k</td>
                                            <td><img src="{{url('public/frontend/img/icon/j4.png')}}" alt="">London Jackpot</td>
                                        </tr>
                                        <tr>
                                           <td><img src="{{url('public/frontend/img/icon/m5.png')}}" alt="">Ragner Lorth</td>
                                            <td>02-03-2019</td>
                                            <td>
                                               <ul class="self-number">
                                                    <li><a href="#">12</a></li>
                                                    <li><a href="#">23</a></li>
                                                    <li><a href="#">24</a></li>
                                                    <li><a href="#">26</a></li>
                                                    <li><a href="#">31</a></li>
                                                </ul>
                                            </td>
                                            <td>$150k</td>
                                            <td><img src="{{url('public/frontend/img/icon/j5.png')}}" alt="">Powerball</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End payment-history area -->