 <!-- Start Subscribe area -->
 <div class="subscribe-area fix area-padding">
            <div class="container">
                <div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="section-headline text-center">
                            <h3>Subscribe Newsletter</h3>
                            <p>Help agencies to define their new business objectives and then create professional software.</p>
						</div>
					</div>
				</div>
                <div class="row">
                    <div class="col-md-10 col-md-offset-1 col-sm-12">
                        <div class="subs-form">
							<form id="contactForm" method="POST" action="contact.php" class="contact-form">
								<input type="email" class="email form-control" id="email" placeholder="Email" required data-error="Please enter your email">
								<button type="submit" id="submit" class="add-btn">Subscribe</button>
							</form>  
                        </div>
                    </div>
                </div>
                <!-- Start counter Area -->
               <!-- <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="card-list payment-carousel">
                            <div class="single-card">
                                <a href="#"><img src="{{url('public/frontend/img/brand/1.png')}}" alt=""></a>
                            </div>
                            <div class="single-card">
                                <a href="#"><img src="{{url('public/frontend/img/brand/2.png')}}" alt=""></a>
                            </div>
                            <div class="single-card">
                                <a href="#"><img src="{{url('public/frontend/img/brand/3.png')}}" alt=""></a>
                            </div>
                            <div class="single-card">
                                <a href="#"><img src="{{url('public/frontend/img/brand/4.png')}}" alt=""></a>
                            </div>
                            <div class="single-card">
                                <a href="#"><img src="{{url('public/frontend/img/brand/5.png')}}" alt=""></a>
                            </div>
                            <div class="single-card">
                                <a href="#"><img src="{{url('public/frontend/img/brand/6.png')}}" alt=""></a>
                            </div>
                            <div class="single-card">
                                <a href="#"><img src="{{url('public/frontend/img/brand/7.png')}}" alt=""></a>
                            </div>
                            <div class="single-card">
                                <a href="#"><img src="{{url('public/frontend/img/brand/8.png')}}" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
        <!-- End Subscribe area -->