<!-- Start About Area -->
<div class="about-area about-area-3 fix area-padding">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="about-video">
                            <img src="{{url('public/frontend/img/about/ab.jpg')}}" alt="">
                            <div class="video-content">
                                <a href="https://www.youtube.com/watch?v=O33uuBh6nXA" class="video-play vid-zone">
                                    <i class="fa fa-play"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="about-content">
                            <div class="section-headline">
                                <h3>Powerbal provides high secure system</h3>
                                <p>The phrasal sequence of the Lorem Ipsum text is now so widespread and commonplace that many DTP programmes can generate dummy text using the starting sequence "Lorem ipsum". Fortunately, the phrase 'Lorem Ipsum' is now recognized by electronic pre-press systems and, when found, an alarm can be raised.</p>
                            </div>
                            <div class="about-company">
                                <div class="single-about">
									<span class="about-text">Professional team</span>
									<span class="about-text">Server secure payments</span>
									<span class="about-text">Live hat upport</span>
                                </div>
                                <div class="single-about">
									<span class="about-text">Goal achivment</span>
									<span class="about-text">Worldwide services company</span>
									<span class="about-text">Marketing expert policy</span>
                                </div>
                            </div>
                        </div>
                    </div>
                 </div>
            </div>
        </div>
        <!-- End About Area -->