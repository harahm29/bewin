<!-- Start Choose area -->
<div class="choose-area area-padding-2">
            <div class="container">
                <div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="section-headline text-center">
							<h3>Why Choose</h3>
							<p>Dummy text is also used to demonstrate the appearance of different typefaces and layouts</p>
						</div>
					</div>
				</div>
                <div class="row">
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <!-- Start services -->
                        <div class="support-services">
                            <img class="support-images" src="{{url('public/frontend/img/about/ab-icon.png')}}" alt="">
                            <div class="support-content">
                                <h4>Online lottery</h4>
                                <p>Replacing a  maintains the amount of lines. When replacing a selection. </p>
                            </div>
                        </div>
                    </div>
                    <!-- Start services -->
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="support-services">
                            <img class="support-images" src="{{url('public/frontend/img/about/ab-icon2.png')}}" alt="">
                            <div class="support-content">
                                <h4>100% Secure</h4>
                                <p>Replacing a  maintains the amount of lines. When replacing a selection. </p>
                            </div>
                        </div>
                    </div>
                    <!-- Start services -->
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="support-services">
                            <img class="support-images" src="{{url('public/frontend/img/about/ab-icon3.png')}}" alt="">
                            <div class="support-content">
                                <h4>Instant Cashout</h4>
                                <p>Replacing a  maintains the amount of lines. When replacing a selection. </p>
                            </div>
                        </div>
                    </div>
                    <!-- Start services -->
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="support-services">
                            <img class="support-images" src="{{url('public/frontend/img/about/ab-icon4.png')}}" alt="">
                            <div class="support-content">
                                <h4>Live Support</h4>
                                <p>Replacing a  maintains the amount of lines. When replacing a selection. </p>
                            </div>
                        </div>
                    </div>
                    <!-- Start services -->
                </div>
            </div>
        </div>
        <!-- End Choose area -->