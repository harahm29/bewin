<html lang="en">
@include('includes.admin-head')
<body>
<div id="preloader"></div>
@include('includes.admin-header')

@yield('content')


@include('includes.admin-footer')
</body>

</html>